/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//All the libraries
#include "project.h"
#include "math.h"
#include "time.h"
#include "keypad.h"
#include "stdbool.h"

//Global Constants
#define N 100 //Array size of the sinus function used for the sound
#define threshold 1200 //measured before the test in light mode, to detect the obstacles
#define threshold_nuit 120 //measured before the test in dark mode, to detect the obstacles
const double Pi = 3.14159265359; //definition of Pi bc math.h wouldn't work for pi

//Variables
uint32_t adcp;
uint16 pwm_period = 48000;

char8 rxData;
clock_t start_clock;
int score = 0;
int gamestatus=0;
bool overFlow;

float signalj[N];
float signald[N];
float blanc[N];
float *signal_principal;

int i=0;
int k=0;
char8 texte[4];
int delai = 80;
int delai_1=300;


// Fonctions
int photores();
void jump();
void duck();
void score_start();
void sw();
void keyboard();
void led();
void LCD_message();
void audio_out();
void serial_port();
void algo();

CY_ISR(sw3){ 
    score = 0; //game has stopped
    gamestatus=0;
    delai = 80;
    delai_1=300;
    SW3_ClearInterrupt();
}

CY_ISR(score_sec){
    if (gamestatus==1)score +=10;
    TimerISR_ReadStatusRegister();
    switch (score){
            case 250:
                delai_1=270;
                break;

            case 370:
                delai_1=250;
                break;
                
            case 550:
                delai_1=200;
                break;
        
            default:
              break;
    }
    /*
    if (score == 250) delai_1=270;
    //7cm du bord de la tablette
    else if (score == 370) delai_1=250;
    else if (score == 550) delai_1=200;*/
    
    
    //if (score == 250) delai = 70, delai_1=20;
    //else if (score == 400) delai = 60, delai_1=10;
}

CY_ISR(UART){// Interrupt for the UART
    uint8 status = 0;
    do{
        // Checks if no UART Rx errors
        status = UART_ReadRxStatus();
        if ((status & UART_RX_STS_PAR_ERROR) || (status & UART_RX_STS_STOP_ERROR) || (status & UART_RX_STS_BREAK) || (status & UART_RX_STS_OVERRUN) ) {
            // Parity, framing, break or overrun error
            // ... process error
            LCD_Position(1,0);
            LCD_PrintString("UART err");
        }
        // Check that rx buffer is not empty and get rx data
        
        if ( (status & UART_RX_STS_FIFO_NOTEMPTY) != 0){   
            rxData = UART_ReadRxData();
                
            //LCD_PutChar(rxData);
            //CyDelay(100);
            /*while(k<4){
                if (rxData != '\n'){
                texte[k] = rxData;
                k++;
                }
                else break;
            }
            k = 0;*/
            
            if (rxData != '\n' && k < 4){
                texte[k] = rxData;
                k++;
            }
            else{
                k=0;
                if (strcmp(texte, "jump")==0){
                    jump();
                }
                else if(strcmp(texte, "duck")==0){
                    duck();
                }
            }
            
            
            
            //LCD_Position(0,0);
            //CyDelay(100);
            //LCD_PrintString(texte);
            /*
            switch (texte){
            case "jump":
                jump();
                break;

            case "duck":
                duck();
                break;
                                    
            default:
              break;
        }*/
            
            
        }
    }while ((status & UART_RX_STS_FIFO_NOTEMPTY) != 0);
}

CY_ISR (SOUND){ //Interrupt for the sound update
    uint8_t value = 128 + 128*signal_principal[i];
    VDAC_SetValue(value);
    i++; 
    if (i==N){i=0;}    
    Timer_DAC_ISR_ReadStatusRegister(); //Do not forget to reset the register
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    //To generate the sine function
    for (int j=0; j<N; j++){
        signalj[j]= 0.5*sin(10*Pi*j/N);
        signald[j]=0.5*sin(5*Pi*j/N);
        blanc[j]=0;
    }
    signal_principal=&blanc;//To start with no sound
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //Init of components
    keypadInit();
    ADC_Start();
    LCD_Start();
    Mux_Start();
    PWM_Start(); 
    PWM_WritePeriod(pwm_period);
    PWM_WriteCompare1(0);
    PWM_WriteCompare2(0);
    UART_Start();
    isr_uart_StartEx(UART);
    isr_sw3_StartEx(sw3);
    isr_score_StartEx(score_sec);
    TimerISR_Start();
    ISR_Timer_DAC_StartEx(SOUND);
    Timer_DAC_ISR_Start();
    VDAC_Start();
    VDAC_SetValue(0);
    
    //for(int j= 0; j<N ;j++){
      //  el[j]= sin(2*PI*j/N);
    //}
    for(;;)
    {   
        
        //LCD_ClearDisplay();
        //LCD_PrintNumber(12);
        int val_jump = photores(0);
        int val_duck = photores(1);
        //algo(val_jump, val_duck);
        //jump();
        //CyDelay(500);
        //duck();
        sw();
        keyboard();
        //audio_out();
        LCD_ClearDisplay();
        //LCD_PrintNumber(delai);
        LCD_Position(1,0);
        LCD_PrintNumber(score);
        
        //score_start(2);
        /*
        if(0x80 & Timer_DAC_ISR_ReadStatusRegister()){
            uint8_t value = 128 + 128*signal_principal[i];
            VDAC_SetValue(value);
            i++;
            if (i==N){i=0;}    
            Timer_DAC_ISR_ReadStatusRegister();
        }
        CyDelay(10);
        */
        
    }
}
int photores(int port){
    int val = 0; //return value, 
    uint32_t adc_val;
    Mux_Select(port);
    ADC_StartConvert();
        if(ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)!=0){
            adc_val = ADC_GetResult32();
            adcp=(adc_val*5000/(0xFFFF));
        };
        if ((adcp<threshold && score<700) || (adcp>threshold_nuit && score>700)){
            val=1;
        }else val = 0;
    //LCD_Position(0,0);
    //LCD_PrintNumber(adcp);
        
    return val;

}

void jump(void){
    gamestatus=1; //game has begun 
    
    UART_PutString("Jump\n");
    
    LED1_Write(0);
    LED2_Write(0);
    LED3_Write(1);
    LED4_Write(1);
    
    LCD_Position(0,0);
    CyDelay(delai_1);//delay before the jump, decreases with speed of 
                     //the game
    signal_principal = &signalj; //son jump
    LCD_PrintString("Jump");
    PWM_WriteCompare1(4250); //down
    CyDelay(delai);
    PWM_WriteCompare1(4800); // up
    signal_principal = &blanc; //son mute
    LCD_ClearDisplay();
    
    
    
}

void duck(void){
    UART_PutString("Duck\n");
    
    LED1_Write(1);
    LED2_Write(1);
    LED3_Write(0);
    LED4_Write(0);
    
    LCD_Position(0,0);
    LCD_PrintString("Duck");
    CyDelay(delai_1); //delay before the duck, decreases with speed of 
                      //the game
    signal_principal = &signald; //son duck
    PWM_WriteCompare2(4280); //down
    CyDelay(100);
    PWM_WriteCompare2(4800); // up
    LCD_Position(0,0);
    signal_principal = &blanc; //son mute
    LCD_ClearDisplay();
}

void sw(){
    if (SW1_Read() ==1){
        jump();
    }
    else if (SW2_Read() ==1){
        duck();
    } 
}
void keyboard(){
    char numb = keypadScan();
    if (numb == '#') jump();
    else if (numb == '*') duck();
}
/*void audio_out(){
    uint8 status = Timer_1_ReadStatusRegister();
    VDAC_SetValue(128);
    if(0x80 & status){
        //Led1_Write(1);
        int val = 128 + signal[i]*128.0;
        if (val != 256){
            VDAC_SetValue(val);
            LCD_PrintNumber(signal[i]);
            
            
            
        }    
        i++;
        if (i == N){
            i = 0;
        }
    }
    


}
*/
void algo(int val_jump, int val_duck){
        /*
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintNumber(val_jump);
        LCD_Position(1,0);
        LCD_PrintNumber(val_duck);
        */
    
        if (val_jump==1 && val_duck==1) jump();
        else if (val_jump==1 && val_duck==0) jump(); //jump avec hauteur plus basse
        else if (val_jump==0 && val_duck==1) duck();
        
        
}
        
        

/*
void score_start(int arg){
    if (arg == 1){
        start_clock = clock();
        score = 0;
    }
    else if (arg == 2){
        clock_t end_clock = clock();
        int a = (int)(end_clock - start_clock)/CLOCKS_PER_SEC ;
        if (a >= 10) {score += 10;};
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintNumber(score);
    }
}
*/

/* [] END OF FILE */
