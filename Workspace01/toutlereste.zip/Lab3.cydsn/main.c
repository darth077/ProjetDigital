/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
void manip1();
void manip3();
uint32_t adc_val;
uint32_t adcp;
uint8 rxData;

CY_ISR(zayd){
    uint8 status = 0;
    do{
        // Checks if no UART Rx errors
        status = UART_ReadRxStatus();
        if ((status & UART_RX_STS_PAR_ERROR) || (status & UART_RX_STS_STOP_ERROR) || (status & UART_RX_STS_BREAK) || (status & UART_RX_STS_OVERRUN) ) {
            // Parity, framing, break or overrun error
            // ... process error
            LCD_Position(1,0);
            LCD_PrintString("UART err");
        }
        // Check that rx buffer is not empty and get rx data
        if ( (status & UART_RX_STS_FIFO_NOTEMPTY) != 0){
            rxData = UART_ReadRxData();
            UART_PutChar(rxData);
            LCD_Position(1,0);
            //("     ");
            LCD_Position(1,0);
            LCD_PutChar(rxData);
            
        }
    }while ((status & UART_RX_STS_FIFO_NOTEMPTY) != 0);
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    //Manip1
    uint16 pwm_period = 48000;
    PWM_WritePeriod(pwm_period);
    PWM_Start();
    Clock_1_Start();
    ADC_Start();
    LCD_Start();
    ADC_StartConvert();
    //Manip3
    UART_Start();
    isr_uart_StartEx(zayd);
    LCD_ClearDisplay();
    
    for(;;)
    {
        /* Place your application code here. */
        manip1();
        //manip3();
    }
}
void manip1(void){
    if(ADC_IsEndConversion(ADC_RETURN_STATUS)){
        adc_val = ADC_GetResult32();
        adcp=((adc_val/(float)0xFFFF) + 1)*2400;
        if (adcp>=4800 ){
            adcp = 4800;
        }
        if( adcp<=2400){
            adcp = 2400;
        }
        
        PWM_WriteCompare(adcp);
        LED1_Write(1);
    }
    LCD_Position(0,0);
    LCD_ClearDisplay();
    LCD_PrintNumber(adcp);
    CyDelay(50);
}
void manip3(void){
    UART_PutString("a");
    CyDelay(350);

}
/* [] END OF FILE */
