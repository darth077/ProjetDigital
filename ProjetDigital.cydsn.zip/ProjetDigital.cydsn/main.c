// Libraries
#include "project.h"
#include "math.h"
#include "time.h"
#include "keypad.h"
#include "stdbool.h"
//#include "emotional_damage.h"

// Global Constants
#define N 100 // Array size of the sinus function used for the sound
#define threshold 1600 // Value measured before the test in light mode, to detect the obstacles
#define threshold_duck 1100
#define threshold_duck_nuit 350
#define threshold_nuit 300 // Value measured before the test in dark mode, to detect the obstacles
#define thresh_hold_transition 1000
const double Pi = 3.14159265359; // Definition of Pi bc math.h wouldn't work for pi
const uint16 pwm_period = 48000;
int x = 40;
int i = 0;
int k = 0;
char8 texte[4];
// Variables
int gamestatus = 0; // 0 if the game is stopped, 1 if the game is running
int score = 0;
float signalj[N]; // Jump sound signal
float signald[N]; // Duck sound signal
float no_sound[N];
float *signal_principal;
int jump_time = 80; // Time during which the dino is jumping 
int duck_time = 240;
int action_delay=260; // Delay between the detection of obstacle and the jump/duck
char couleur = 'd';
int Noir=0;
int Blanc=0;

// Functions
int photores();
void jump();
void duck();
void score_start();
void sw();
void keyboard();
void led();
void LCD_message();
void audio_out();
void serial_port();
void algo();

CY_ISR(switch3){
    score = 0; // Game has stopped
    gamestatus=0;
    jump_time = 100;
    action_delay = 300-x;
    SW3_ClearInterrupt();
}

CY_ISR(score_and_delay){
    if (gamestatus==1) score +=10;
    TimerISR_ReadStatusRegister();
    // Adjustment of jumping delay
    switch (score){
            case 250:
                action_delay=270-2*x;
                break;

            case 370:
                action_delay=250-2*x;
                break;
                
            case 550:
                action_delay=200-2*x;
                break;
        
            default:
              break;
    }
}

CY_ISR(UART){// Interrupt for the UART, based on the code from the lab sessions
    uint8 status = 0;
    char8 rxData;
    do{
        // Checks if no UART Rx errors
        status = UART_ReadRxStatus();
        if ((status & UART_RX_STS_PAR_ERROR) || (status & UART_RX_STS_STOP_ERROR) || (status & UART_RX_STS_BREAK) || (status & UART_RX_STS_OVERRUN) ) {
            // Parity, framing, break or overrun error
            // ... process error
            LCD_Position(1,0);
            LCD_PrintString("UART err");
        }
        // Check that rx buffer is not empty and get rx data

        // Code from computer to UART
        if ( (status & UART_RX_STS_FIFO_NOTEMPTY) != 0){   
            rxData = UART_ReadRxData();

            // Collect the letters for "jump" and "duck" in an array
            if (rxData != '\n' && k < 4){
                texte[k] = rxData;
                k++;
            }
            // Computer input analysis
            else{
                k=0;
                if (strcmp(texte, "jump")==0){
                    jump();
                }
                else if(strcmp(texte, "duck")==0){
                    duck();
                }
            }
        }
    }
    while ((status & UART_RX_STS_FIFO_NOTEMPTY) != 0);
}

CY_ISR (SOUND){ //Interrupt for the sound update
    uint8_t value = 128 + 128*signal_principal[i];
    VDAC_SetValue(value);
    i++; 
    if (i==N) i=0;
    Timer_DAC_ISR_ReadStatusRegister(); //To reset the register
}


int main(void)
{
    CyGlobalIntEnable;
    //To generate the sine function
    for (int j=0; j<N; j++){
        signalj[j]= 1*sin(10*Pi*j/N);
        signald[j]=1*sin(5*Pi*j/N);
        no_sound[j]=0;
    }
    signal_principal = &no_sound; // To start without sound

    //Init of components
    keypadInit();
    ADC_Start();
    LCD_Start();
    Mux_Start();
    PWM_Start(); 
    PWM_WritePeriod(pwm_period);
    PWM_WriteCompare1(0); //Compare1 to use the first output of the PWM
    PWM_WriteCompare2(0); //Compare2 to use the second output of the PWM
    UART_Start();
    isr_uart_StartEx(UART);
    isr_sw3_StartEx(switch3);
    isr_score_StartEx(score_and_delay);
    TimerISR_Start();
    ISR_Timer_DAC_StartEx(SOUND);
    Timer_DAC_ISR_Start();
    VDAC_Start();
    VDAC_SetValue(0);
    
    for(;;)
    {   
        
        int val_jump = photores(0);
        int val_duck = photores(1);
        algo(val_jump, val_duck);
        sw();
        keyboard();
        //audio_out();
        LCD_ClearDisplay();
        LCD_Position(1,0);
        LCD_PrintNumber(score);
        
        
    }
}
int photores(int port){
    int val = 0;
    uint32_t adc_val; //32 bit voltage value of the photoresistor
    int adcp; //
    Mux_Select(port); //To select the desired photoresistor
    ADC_StartConvert();
    if(ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)!=0){
        adc_val = ADC_GetResult32();
        adcp=(adc_val*5000/(0xFFFF)); //conversion of adc_val in an integer form
    };
    
    switch (couleur) {
        case 'n':
            if (port ==1){
                if (adcp>threshold_duck_nuit){
                val=1;
                }
            }
            else {
                if (adcp>threshold_nuit){
                val=1;
                }
            }
            if (adcp > thresh_hold_transition) {
                Blanc++;
                if(Blanc > 2)
                {
                    couleur = 'd';
                    LCD_ClearDisplay();
                    LCD_PrintString("Day");
                    Blanc = 0;
                }
            }
            else Blanc = 0;
            break;
        case 'd':
            if (port ==1){
                if (adcp<threshold_duck){
                val=1;
                }
            }
            else {
                if (adcp<threshold){
                val=1;
                }
            }
            
            if (adcp < thresh_hold_transition) {
                Noir++;
                if(Noir > 2)
                {
                    couleur = 'n';
                    LCD_ClearDisplay();
                    LCD_PrintString("Night");
                    Noir = 0;
                    
                }
            }
            else Noir = 0;
            break;
        default:
            break;
    }
    
    
    if(port ==0){
        LCD_Position(0,0);
        LCD_PrintNumber(adcp);
     
        }
    
    else{
        LCD_Position(0,0);
        LCD_PrintNumber(adcp);
    }
    /*
    LCD_Position(0,0);
    LCD_PutChar(couleur);
    */
    return val;

}
void jump(void){
    gamestatus=1; //game has begun 
    
    UART_PutString("Jump\n");
    
    LED1_Write(0);
    LED2_Write(0);
    LED3_Write(1);
    LED4_Write(1);
    
    LCD_Position(0,0);
    CyDelay(action_delay);//delay before the jump, decreases with speed of the game
    signal_principal = &signalj; // Jump sound
    LCD_PrintString("Jump");
    PWM_WriteCompare1(4150); //down
    CyDelay(jump_time);
    PWM_WriteCompare1(4800); // up
    signal_principal = &no_sound; //son mute
    LCD_ClearDisplay();
}

void duck(void){
    UART_PutString("Duck\n");
    
    LED1_Write(1);
    LED2_Write(1);
    LED3_Write(0);
    LED4_Write(0);
    
    LCD_Position(0,0);
    LCD_PrintString("Duck");
    CyDelay(action_delay); //delay before the duck, decreases with speed of the game                   
    signal_principal = &signald; //son duck
    PWM_WriteCompare2(4280); //down
    CyDelay(duck_time);
    PWM_WriteCompare2(4800); // up
    LCD_Position(0,0);
    signal_principal = &no_sound; //son mute
    LCD_ClearDisplay();
}


void sw(){
    if (SW1_Read() ==1){
        jump();
    }
    else if (SW2_Read() ==1){
        duck();
    } 
}
void keyboard(){
    char numb = keypadScan();
    if (numb == '#') jump();
    else if (numb == '*') duck();
}

void algo(int val_jump, int val_duck){
        if (gamestatus==1){
        if (val_jump==1 && val_duck==1) jump();
        else if (val_jump==1 && val_duck==0) jump(); //jump avec hauteur plus basse
        else if (val_jump==0 && val_duck==1) duck();}
        
        
}




/* [] END OF FILE */
