/*******************************************************************************
* File Name: TimerISR_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "TimerISR.h"

static TimerISR_backupStruct TimerISR_backup;


/*******************************************************************************
* Function Name: TimerISR_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerISR_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void TimerISR_SaveConfig(void) 
{
    #if (!TimerISR_UsingFixedFunction)
        TimerISR_backup.TimerUdb = TimerISR_ReadCounter();
        TimerISR_backup.InterruptMaskValue = TimerISR_STATUS_MASK;
        #if (TimerISR_UsingHWCaptureCounter)
            TimerISR_backup.TimerCaptureCounter = TimerISR_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!TimerISR_UDB_CONTROL_REG_REMOVED)
            TimerISR_backup.TimerControlRegister = TimerISR_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: TimerISR_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerISR_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void TimerISR_RestoreConfig(void) 
{   
    #if (!TimerISR_UsingFixedFunction)

        TimerISR_WriteCounter(TimerISR_backup.TimerUdb);
        TimerISR_STATUS_MASK =TimerISR_backup.InterruptMaskValue;
        #if (TimerISR_UsingHWCaptureCounter)
            TimerISR_SetCaptureCount(TimerISR_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!TimerISR_UDB_CONTROL_REG_REMOVED)
            TimerISR_WriteControlRegister(TimerISR_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: TimerISR_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerISR_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void TimerISR_Sleep(void) 
{
    #if(!TimerISR_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(TimerISR_CTRL_ENABLE == (TimerISR_CONTROL & TimerISR_CTRL_ENABLE))
        {
            /* Timer is enabled */
            TimerISR_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            TimerISR_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    TimerISR_Stop();
    TimerISR_SaveConfig();
}


/*******************************************************************************
* Function Name: TimerISR_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerISR_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void TimerISR_Wakeup(void) 
{
    TimerISR_RestoreConfig();
    #if(!TimerISR_UDB_CONTROL_REG_REMOVED)
        if(TimerISR_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                TimerISR_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
