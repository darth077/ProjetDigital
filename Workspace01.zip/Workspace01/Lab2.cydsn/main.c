/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdbool.h"
#include "math.h"
//const int N = 100;
#define N 1000
const double PI = 3.14159265359;
void manip2();
void manip3(); 
void manip4(); 
bool overFlow;
float el[N];
int val;
int i=0;

CY_ISR(zayd)
{
    int val = 128 + el[i]*128.0;
    if (val != 256){
        VDAC_SetValue(val);
    }    
    i++;
    if (i == N){
        i = 0;
    }
    TimerISR_ReadStatusRegister();
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    LCD_Start();
    Timer_1_Start();
    /*manip3*/
    VDAC_Start();
    VDAC_SetValue(0);
    /*manip4*/
    //TimerISR_Start();
    isr_dac_StartEx(zayd);
    
    for(int j= 0; j<N ;j++){
        el[j]= sin(2*PI*j/N);
    }
    for(;;)
    {
        //manip2();
        /* Place your application code here. */
        manip3();
        //manip4();
    }
}

void manip2(void){
    uint8 status = Timer_1_ReadStatusRegister();
    if(0x80 & status){
        Led1_Write(1);
        LED2_Write(1);
        LED3_Write(1);
        LED4_Write(1);
    }
    else {
        Led1_Write(0);
        LED2_Write(0);
        LED3_Write(0);
        LED4_Write(0);
    }

}
void manip3(void){
    uint8 status = Timer_1_ReadStatusRegister();
    if(0x80 & status){
        //Led1_Write(1);
        int val = 128 + el[i]*128.0;
        if (val != 256){
        VDAC_SetValue(val);
        }    
        i++;
        if (i == N){
            i = 0;
        }
    }
    LCD_Position(0,0);
    LCD_ClearDisplay();
    LCD_PrintNumber(el[i]*128 +128);
}
void manip4(void){
    LCD_Position(0,0);
    LCD_ClearDisplay();
    LCD_PrintNumber(el[i]*128 +128);
}
/* [] END OF FILE */
